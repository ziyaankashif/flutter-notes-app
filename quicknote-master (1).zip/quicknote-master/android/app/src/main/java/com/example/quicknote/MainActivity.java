package com.example.quicknote;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
